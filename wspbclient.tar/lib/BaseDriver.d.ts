import { AWebSocket, CLOSE_CODE, DataBuf, pbMessage, PbParser, UpstreamDrivable, WebSocketDriver, WebSocketEventHandler } from "./types.js";
/**
 * Stackable drivers to move pbMessages up/down from/to websocket.
 *
 * **Note**: the 'O' messages are embedded inside the 'I' messages.. TODO: fix
 * @I (INNER) the pbMessage THIS driver handles; this.derserialize(): I
 * @O (OUTER) the pbMessage of outer driver/app; upstream.deserialze(): O
 */
export declare class BaseDriver<I extends pbMessage, O extends pbMessage> implements WebSocketDriver<I, O>, EventTarget, PbParser<I> {
    dnstream: UpstreamDrivable<I>;
    upstream: WebSocketEventHandler<O>;
    log: number;
    ll(l: number): boolean;
    newMessageEvent(data: DataBuf<I>): MessageEvent;
    isBrowser: boolean;
    newEventTarget(): EventTarget;
    et: EventTarget;
    addEventListener(type: string, listener: EventListenerOrEventListenerObject, options?: boolean | AddEventListenerOptions): void;
    dispatchEvent(event: Event): boolean;
    removeEventListener(type: string, callback: EventListenerOrEventListenerObject, options?: boolean | EventListenerOptions): void;
    /** Connect to downstream Driver & tell it to connectUpStream to us.
     * this.dnstream = dnstream; dnstream.upstream = this
     */
    connectDnStream(dnstream: UpstreamDrivable<I>): this;
    /** Connect to upstream driver:
     * send open/error/close/wsmessage events to upstream.
     *
     * Typically override wsmessage(data\<O>) to parseEval(deserialize(data\<O>))
     * which may upstream.wsmessage(msg_data\<I>)
     * @param upstream
     */
    connectUpStream(upstream: WebSocketEventHandler<O>): void;
    /** Listener for dnstream 'open' event; invoke upstream.onopen(ev) */
    onopen(ev: Event): void;
    /** Listener for dnstream 'error' events;nvoke upstream.onerror(ev) */
    onerror(ev: ErrorEvent): void;
    /** listener for dnstream 'close' event; invoke upstream.onclose(ev) */
    onclose(ev: CloseEvent): void;
    /**
     * BaseDriver Listener for Message Data.
     * - logData(data)
     *
     * _Implicit_ Listener: this.wsmessage(data, wrapper) => this.onmessage(data);
     * when: this.dispatchMessageEvent(data); then also this.onmessage(data)
     * - typically do not register explicit 'message' listener
     * - typically do not register for 'message' [wrapper] from dnstream
     *
     * Typically override to:
     *  { this.parseEval(this.deserialize(data)) }
     */
    onmessage(data: DataBuf<I>): void;
    /**
     * BaseDriver hander for (data: DataBuf<I>) from dnstream.
     * - save this.wrapper = wrapper [may be undefined]
     * - invoke this.dispatchMessageEvent(data)
     * - invoke this.onmessage(data)
     * @param data DataBuf\<I> from the up-coming event
     * @param wrapper the encapsulating pbMessage, if dnstream.send(wrapper.msg\<I>)
     */
    wsmessage(data: DataBuf<I>, wrapper?: pbMessage): void;
    /** wrapper for the latest wsmessage(data) received (or undefined if no wrapper supplied) */
    wrapper: pbMessage;
    stringData(data: DataBuf<I>): string;
    logData(data: DataBuf<I>): {} | string;
    /**
     * Deliver MessageEvent(data) to 'message' listeners: {type: 'message', data: data}.
     * @param data
     * @param logLevel = 2; set lower if you want to see more!
     */
    dispatchMessageEvent(data: DataBuf<I>, ll?: number): void;
    /** convert DataBuf\<I\> to pbMessage
     * @abstract derived classes must override
     */
    deserialize(data: DataBuf<I>): I;
    /**
     * BaseDriver: Execute the semantic actions of the pbMessage: I
     *
     * typically: this[\`eval_${message.msgType}\`].call(this, message, ...args)
     * @param message from deserialized DataBuf\<I\> (from dnstream)
     * @abstract derived classes must override
     */
    parseEval(message: I, ...args: any): void;
    /** Process data from upstream by passing it dnstream. */
    sendBuffer(data: DataBuf<O>): void;
    /** Process close request by sending it dnstream */
    closeStream(code?: CLOSE_CODE, reason?: string): void;
}
export declare type AnyWSD = WebSocketDriver<pbMessage, pbMessage>;
/**
 * Bottom of the websocket driver stack: connect actual WebSocket.
 *
 * Send & Recieve messages over a given WebSocket.
 */
export declare class WebSocketBase<I extends pbMessage, O extends pbMessage> extends BaseDriver<I, O> {
    ws: AWebSocket;
    /**
     * Stack the given drivers on top of this WebSocketBase, then connectWebSocket(ws|url)
     *
     * TODO: is there a Generic Type for the chain of drivers (COD)?
     *
     * COD\<I extends pbMessage, O extends pbMessage> = d0\<I,X0>, d1\<X0,X1>, d2\<X1,X2 extends O>
     */
    connectStream(ws: AWebSocket | string, ...drivers: Array<{
        new (): AnyWSD;
    }>): AnyWSD[];
    /**
     * Connect to Downstream 'Driver'; BaseDriver connects directly to AWebSocket [or URL->new WebSocket()].
     * @param ws_or_url existing AWebSocket or string -> new WebSocket() [on Browser]
     * @returns this WebSocketBase
     * @override to accept AWebSocket | string
     */
    connectDnStream(ws_or_url: AWebSocket | string | UpstreamDrivable<O>): this;
    /** Implements connectDnStream(WebSocketDriver) -> connect to WebSocket|url.
     * @param ws the WebSocket (or url) connection to be handled. (or null)
     * Can also be a SocketSender (ie another CnxHandler)
     */
    connectWebSocket(ws: AWebSocket | string): this;
    /**
     * Forward data from WebSocket to upstream driver:
     * Every message(DataBuf<I>) is an implicit send_send(DataBuf<O>)
     * @param data DataBuf containing \<I extends pbMessage>
     * @override BaseDriver
     */
    onmessage(data: DataBuf<I>): void;
    /** process data from upstream by passing it downsteam. */
    sendBuffer(data: DataBuf<O>): void;
    /** invoke WebSocket.close(code, reason) */
    closeStream(code?: CLOSE_CODE, reason?: string): void;
}
