import { BaseDriver } from "./BaseDriver.js";
import { CgMessage, CgType } from "./CgProto.js";
import { DataBuf, EzPromise, pbMessage, WebSocketDriver } from "./types.js";
/** a DOM event of type 'leave'. emit when (for ex) dnstream.close */
export declare class LeaveEvent extends Event {
    client_id: number;
    cause?: number;
    group?: string;
    constructor(client_id: number, cause?: number, group?: string);
}
declare module './CgProto' {
    interface CgMessage {
        /** @return true for: none, send, join; false for ack, leave */
        expectsAck: boolean;
        /** extract and stringify fields of CgMessage | CgMessageOpts */
        msgObject(asStr?: boolean): CgMessageOpts | string;
        /** inner message as msgPeek+stringChars(msg) */
        msgStr: string;
        /**
         * Peek at inner msg without deserializing it.
         * this.msg defined for send OR ack(send)
         * send[type+length] OR Ack[2+length]
         */
        msgPeek: string;
        /** @return CgType as a string: CgType[this.type] */
        msgType: string;
    }
}
declare type CGMKw = "serialize" | "outObject" | "expectsAck";
declare type CGMKx = "msgType" | "msgPeek" | "msgStr";
declare type CGMK = Exclude<keyof CgMessage, Partial<keyof pbMessage> | CGMKw | CGMKx>;
/** Attributes that can be set when making/sending a CgMessage. */
export declare type CgMessageOpts = Partial<Pick<CgMessage, CGMK>>;
/**
 * EzPromise\<CgMessage> which holds the actual message that was sent.
 * If (!this.message.expectsAck) then
 *    (AckPromise.resolved && AckPromise.value) === undefined
 */
export declare class AckPromise extends EzPromise<CgMessage> {
    message: CgMessage;
    constructor(message: CgMessage, def?: (fil: (value: CgMessage | PromiseLike<CgMessage>) => void, rej: (reason?: any) => void) => void);
}
/**
 * Implement the base functiunality for the CgProto (client-group) Protocol.
 * BaseDriver\<I extends CgMessage, O extends pbMessage>>
 */
export declare class CgBase<O extends pbMessage> extends BaseDriver<CgMessage, O> implements WebSocketDriver<CgMessage, pbMessage> {
    static msgsToAck: CgType[];
    /** make new CgMessage() ensuring that client_from is set. */
    makeCgMessage(msgOpts: CgMessageOpts): CgMessage;
    /** group from Ack of join() */
    group_name: string;
    /** client_id from Ack of join() */
    client_id: number;
    /** used in parseEval logging, override in CgServerDriver */
    get client_port(): string | number;
    /**
     * Promise for last outbound message that expects an Ack.
     * private, but .resolved and .message are accessible:
     */
    private promise_of_ack;
    get ack_promise(): AckPromise;
    /** true if last outbound request has been Ack'd */
    get ack_resolved(): boolean;
    get ack_message(): CgMessage;
    get ack_message_type(): string;
    deserialize(bytes: DataBuf<CgMessage>): CgMessage;
    /**
     * parseEval(message = this.deserialize(data))
     *
     * IFF send_send(data.msg) --> this.upstream.wsmessage(data.msg)
     * @param data DataBuf containing \<CgMessage>
     * @override BaseDriver
     */
    onmessage(data: DataBuf<CgMessage>): void;
    logData(data: DataBuf<CgMessage>): {} | string;
    /**
     * @param ev
     * @override
     */
    onerror(ev: ErrorEvent): void;
    /**
     *
     * @param ev
     * @override
     */
    onclose(ev: CloseEvent): void;
    /** extract useful Opts from Ack/Nak (or any CgMessage), reduce AckMessage to CgMessageOpts. */
    ackOpts(opts: CgMessageOpts): CgMessageOpts;
    /**
     * this.sendToSocket(new Ack(success: true), ...opts)
     * @param cause string
     * @param opts optional CgMessageOpts | CgMessage
     * @return AckPromise (ackPromise.value is undefined)
     */
    sendAck(cause: string, opts?: CgMessageOpts): AckPromise;
    /**
     * this.sendToSocket(new Ack(success: false), ...opts)
     * @param cause
     * @param opts CgMessageOpts | CgMessage
     * @returns
     */
    sendNak(cause: string, opts?: CgMessageOpts): AckPromise;
    /** debugging utility */
    innerMessageString(m: CgMessage): string;
    /**
     * If message.expectsAck [Wait for this.ack_promise, then]
     * sendBufer(message) downstream, toward websocket.
     *
     * @param message to be serialized and sent dnstream
     * @param ackPromise do NOT provide; new AckPromise(message)
     * @final do NOT override
     * @return AckPromise(message):
     * .reject(error) if there is an error while sending
     * .fulfill(ackMsg) when Ack for CgType: join, leave, send is received
     * .fulfill(undefined) if !message.expectsAck
     */
    sendToSocket(message: CgMessage, ackPromise?: AckPromise): AckPromise;
    /**
     * send a useless "none" message.
     * @param group
     * @param client_id destination target client or undefined for the whole Group
     * @param cause
     * @return AckPromise
     */
    send_none(group?: string, client_id?: number, cause?: string): AckPromise;
    /**
     * send message from upstream to downstream
     * @param message Object containing pbMessage\<INNER>
     * @param opts
     * client_id: 0 is ref, [null is to Group]
     * nocc: true to prevent copy back, [false is cc to sender]
     */
    send_send(message: O, opts?: CgMessageOpts): AckPromise;
    /**
     * send_join client makes a connection to server group
     * @param group group name
     * @param client_id specify 0 to register as referee; else undefined
     * @param cause specify 'referee' to register as referee; else undefined
     * @returns a Promise that completes when an Ack/Nak is recieved
     */
    send_join(group: string, client_id?: number, cause?: string): AckPromise;
    /**
     * client leaves the connection to server group.
     *
     * The nice way to leave is send this to the Group/Ref, so they know you have gone.
     * Group/Ref forwards to [all] members. (and, apparently, back to the sender)
     *
     * Or Ref/Server can send this to inform client/group that a client is being booted.
     *
     * Recipient[s] simply Ack; if you are booted, you can close the group cnx, or try to rejoin.
     *
     * @param group group_name
     * @param client_id the client_id that is leaving the Group
     * @param cause identifying string
     * @returns a Promise fulfilled(undefined) [there's no Ack]
     */
    send_leave(group: string, client_id?: number, cause?: string, nocc?: boolean): AckPromise;
    /**
     * parse CgType: eval_ each of ack, nak, join, leave, send, none.
     * @param message
     */
    parseEval(message: CgMessage): void;
    /**
     * Pro-forma: process positive Ack from join, leave, send.
     */
    eval_ack(message: CgMessage, req: CgMessage): void;
    /**
     * Pro-forma: process Nak from send. (join & leave do not fail?)
     */
    eval_nak(message: CgMessage, req: CgMessage): void;
    /** informed that a Client wants to join Group; check client_id & passcode. */
    eval_join(message: CgMessage): void;
    /** CgBase informed (by CgServerDriver) that [other] Client has departed Group; OR I've been booted by Ref. */
    eval_leave(message: CgMessage): void;
    /**
     * Action to take after my send_leave.
     * Base: closeStream(0, cause)
     * @param reason included with CLOSE_CODE(Normal) in closeStream()
     */
    leaveClose(reason: string): void;
    /**
     * Process message delivered to Client-Group.
     *
     * For CgServerDriver: override to sendToGroup()
     * else Server would parseEval on behalf of the client...?
     *
     * For CgClient: forward inner message to upstream protocol handler,
     *
     * @param message with message.msg: DataBuf\<O>
     * @returns
     */
    eval_send(message: CgMessage): void;
    /** not used */
    eval_none(message: CgMessage): void;
}
export {};
