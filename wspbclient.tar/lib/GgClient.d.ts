import { GgMessage as GgMessage0, GgType, Rost } from "./GgProto.js";
import { AckPromise, BaseDriver, CgBase, CgMessage, CgMessageOpts, DataBuf, EzPromise, LeaveEvent, pbMessage, WebSocketBase } from "./index.js";
declare type Constructor<T = {}> = new (...args: any[]) => T;
/** Generic Game message: join (client_id, player, name, roster), next, undo, chat(name, inform)...
 */
export interface GgMessage extends GgMessage0 {
    type: GgType | any;
    client: number;
    player: number;
    name: string;
    roster: Rost[];
    client_to: number;
    /** type as a string (vs enum value) */
    get msgType(): string;
}
/** GgMessage.Rost as object: */
export declare type rost = {
    name: string;
    client: number;
    player: number;
};
declare type GGMK = Exclude<keyof GgMessage, Partial<keyof pbMessage> | "serialize">;
export declare type GgMessageOpts = Partial<Pick<GgMessage, GGMK>>;
/** Driver that speaks Generic Game proto above CgBase<GgMessage>: players join, take turns, undo... */
export declare class GgClient<InnerMessage extends GgMessage> extends BaseDriver<GgMessage, pbMessage> {
    ImC: new (opts: any) => InnerMessage;
    CgB: new () => CgBase<InnerMessage>;
    WSB: new () => WebSocketBase<pbMessage, CgMessage>;
    wsbase: WebSocketBase<pbMessage, pbMessage>;
    cgbase: CgBase<InnerMessage>;
    /** Constructor<InnerMessage>(DataBuf) */
    deserialize: (buf: DataBuf<InnerMessage>) => InnerMessage;
    maxPlayers: number;
    player_id: number;
    player_name: string;
    readonly refid = 239;
    get isPlayer(): boolean;
    /**
     * Create a web socket stack
     * @param ImC constructor<InnerMessage>(opts); With: ImC.deserialize(DataBuf) -> InnerMessage
     * @param CgB CgBase<InnerMessage> constructor [if url supplied for connectStack]
     * @param WSB WebSocketBase constructor [if url supplied for connectStack]
     * @param url web socket URL - if provided: connect wsbase(url).then(onOpen(ggClient))
     * @param onOpen callback when WebSocket is open: onOpen(this) => void
     */
    constructor(ImC: new (opts: any) => InnerMessage, CgB?: new () => CgBase<InnerMessage>, WSB?: new () => WebSocketBase<pbMessage, CgMessage>, url?: string, onOpen?: (ggClient: GgClient<InnerMessage>) => void);
    get isOpen(): boolean;
    /** CgBase.ack_promise: Promise with .message from last send_send (or leave, join)
     * is .resolved when an Ack/Nak is receieved.
     */
    get ack_promise(): AckPromise;
    get client_id(): number;
    /**
     * Promise for last inbound CgType.send message (that expects an Ack)
     *
     * client must Ack before emitting a new 'send' (that exepect an Ack)
     */
    message_to_ack: AckPromise;
    sendCgAck(cause: string, opts?: CgMessageOpts): AckPromise;
    sendCgNak(cause: string, opts?: CgMessageOpts): AckPromise;
    /**
     * Send_send via this.dnstream CgBase [after we Ack the previous inbound request]
     * @param message a GgMessage to be wrapped
     * @param cgOpts -- if not supplied, the default for nocc: is undefined, so ref is not self-copied
     */
    send_message(message: InnerMessage, cgOpts?: CgMessageOpts, ackPromise?: AckPromise): AckPromise;
    /**
     * wire-up this GgClient to a CgBase and WebSocketBase to the given URL
     * @param url string URL to the target CgServer server
     * @param onOpen invoked when GgClient/CgBase/WSB connection to server/URL is Open.
     * @returns this GgClient
     */
    connectStack(url: string, onOpen?: (ggClient: GgClient<InnerMessage>) => void): this;
    /**
     * Send GgMessage, get Ack, then wait for a GgMessage that matches predicate.
     * @return promise to be fulfill'd by first message matching predicate.
     * @param sendMessage function to send a message and return an AckPromise
     * @param pred a predicate to recognise the GgMessage response (and fullfil promise)
     */
    sendAndReceive(sendMessage: () => AckPromise, pred?: (msg: InnerMessage) => boolean): EzPromise<InnerMessage>;
    /** make a Game-specific 'join' message... */
    make_join(name: string, opts?: GgMessageOpts): InnerMessage;
    /** send Join request to referee.
     *
     * See also: sendAndReceive() to obtain the response Join fromReferee
     * (which will come to eval_join anyway, with name & player_id)
     */
    send_join(name: string, opts?: GgMessageOpts): AckPromise;
    /**
     * When Cg 'send' message rec'd: dispatchMessageEvent, deserialize and parseEval
     * Set message.client = wrapper.client_from
     * @param data
     * @param wrapper the outer pbMessage (CgProto.type == send)
     * @override BaseDriver
     */
    onmessage(data: DataBuf<InnerMessage>): void;
    parseEval(message: GgMessage): void;
    /**
     * do nothing, not expected
     */
    eval_none(message: GgMessage): void;
    /** display 'cause' in scrolling TextElement */
    eval_chat(message: GgMessage): void;
    /** all the known players (& observers: !realPlayer(player)) gg-ref controls. */
    roster: Array<rost>;
    updateRoster(roster: Rost[]): void;
    /** GgClient: when [this or other] client joins/leaves Game: update roster */
    eval_join(message: GgMessage): void;
    /** invoke table.undo */
    eval_undo(message: GgMessage): void;
    /** invoke table.setNextPlayer(n) */
    eval_next(message: GgMessage): void;
}
/**
 * Add GgReferee functionality to a GgClient<GgMessage> (expect a dnstream CgBase Driver)
 *
 * Eg: class HgReferee extends GgRefMixin<HgMessage, HgClient>(HgClient) {}
 */
export declare function GgRefMixin<InnerMessage extends GgMessage, TBase extends Constructor<GgClient<InnerMessage>>>(Base: TBase): {
    new (...args: any[]): {
        readonly stage: {};
        /**
         * Connect GgRefMixin to given URL.
         * @param onOpen inform caller that CG connection Stack is open
         * @param onJoin inform caller that GgReferee has joined CG
         * @returns the GgRefMixin (like the constructor...)
         */
        joinGroup(url: string, group: string, onOpen: (ggClient: GgClient<InnerMessage>) => void, onJoin?: (ack: CgMessage) => void): typeof this;
        /** listener for LeaveEvent, from dnstream: CgReferee */
        client_leave(event: Event | LeaveEvent): void;
        /** player_id of given client_id (lookup from roster) */
        player_index(client_id: number): number;
        /** GgRefMixin.RefereeBase: message is request to join GAME, assign Player_ID */
        eval_join(message: InnerMessage): void;
        /** send new/departed player's name, client, player in a 'join' Game message;
         * - all players update their roster using included roster: Rost[]
         * @pr {name, client, player} of the requester/joiner;
         * @param info CgMessageOpts = { info }
         */
        send_roster(pr: rost, info?: string): void;
        /** send join with roster to everyone. */
        send_join(name: string, opts?: GgMessageOpts, cgOpts?: CgMessageOpts): AckPromise;
        wsbase: WebSocketBase<pbMessage, pbMessage>;
        cgbase: CgBase<InnerMessage>;
        /** Constructor<InnerMessage>(DataBuf) */
        deserialize: (buf: Uint8Array) => InnerMessage;
        maxPlayers: number;
        player_id: number;
        player_name: string;
        readonly refid: 239;
        readonly isPlayer: boolean;
        ImC: new (opts: any) => InnerMessage;
        CgB: new () => CgBase<InnerMessage>;
        WSB: new () => WebSocketBase<pbMessage, CgMessage>;
        readonly isOpen: boolean;
        /** CgBase.ack_promise: Promise with .message from last send_send (or leave, join)
         * is .resolved when an Ack/Nak is receieved.
         */
        readonly ack_promise: AckPromise;
        readonly client_id: number;
        /**
         * Promise for last inbound CgType.send message (that expects an Ack)
         *
         * client must Ack before emitting a new 'send' (that exepect an Ack)
         */
        message_to_ack: AckPromise;
        sendCgAck(cause: string, opts?: Partial<Pick<CgMessage, "type" | "success" | "group" | "msg" | "client_id" | "client_from" | "cause" | "info" | "ident" | "nocc" | "acks" | "msgObject">>): AckPromise;
        sendCgNak(cause: string, opts?: Partial<Pick<CgMessage, "type" | "success" | "group" | "msg" | "client_id" | "client_from" | "cause" | "info" | "ident" | "nocc" | "acks" | "msgObject">>): AckPromise;
        /**
         * Send_send via this.dnstream CgBase [after we Ack the previous inbound request]
         * @param message a GgMessage to be wrapped
         * @param cgOpts -- if not supplied, the default for nocc: is undefined, so ref is not self-copied
         */
        send_message(message: InnerMessage, cgOpts?: Partial<Pick<CgMessage, "type" | "success" | "group" | "msg" | "client_id" | "client_from" | "cause" | "info" | "ident" | "nocc" | "acks" | "msgObject">>, ackPromise?: AckPromise): AckPromise;
        /**
         * wire-up this GgClient to a CgBase and WebSocketBase to the given URL
         * @param url string URL to the target CgServer server
         * @param onOpen invoked when GgClient/CgBase/WSB connection to server/URL is Open.
         * @returns this GgClient
         */
        connectStack(url: string, onOpen?: (ggClient: GgClient<InnerMessage>) => void): any;
        /**
         * Send GgMessage, get Ack, then wait for a GgMessage that matches predicate.
         * @return promise to be fulfill'd by first message matching predicate.
         * @param sendMessage function to send a message and return an AckPromise
         * @param pred a predicate to recognise the GgMessage response (and fullfil promise)
         */
        sendAndReceive(sendMessage: () => AckPromise, pred?: (msg: InnerMessage) => boolean): EzPromise<InnerMessage>;
        /** make a Game-specific 'join' message... */
        make_join(name: string, opts?: Partial<Pick<GgMessage, GGMK>>): InnerMessage;
        /**
         * When Cg 'send' message rec'd: dispatchMessageEvent, deserialize and parseEval
         * Set message.client = wrapper.client_from
         * @param data
         * @param wrapper the outer pbMessage (CgProto.type == send)
         * @override BaseDriver
         */
        onmessage(data: Uint8Array): void;
        parseEval(message: GgMessage): void;
        /**
         * do nothing, not expected
         */
        eval_none(message: GgMessage): void;
        /** display 'cause' in scrolling TextElement */
        eval_chat(message: GgMessage): void;
        /** all the known players (& observers: !realPlayer(player)) gg-ref controls. */
        roster: rost[];
        updateRoster(roster: Rost[]): void;
        /** invoke table.undo */
        eval_undo(message: GgMessage): void;
        /** invoke table.setNextPlayer(n) */
        eval_next(message: GgMessage): void;
        dnstream: import("./types.js").UpstreamDrivable<GgMessage>;
        upstream: import("./types.js").WebSocketEventHandler<pbMessage>;
        log: number;
        ll(l: number): boolean;
        newMessageEvent(data: Uint8Array): MessageEvent<any>;
        isBrowser: boolean;
        newEventTarget(): EventTarget;
        et: EventTarget;
        addEventListener(type: string, listener: EventListenerOrEventListenerObject, options?: boolean | AddEventListenerOptions): void;
        dispatchEvent(event: Event): boolean;
        removeEventListener(type: string, callback: EventListenerOrEventListenerObject, options?: boolean | EventListenerOptions): void;
        connectDnStream(dnstream: import("./types.js").UpstreamDrivable<GgMessage>): any;
        connectUpStream(upstream: import("./types.js").WebSocketEventHandler<pbMessage>): void;
        onopen(ev: Event): void;
        onerror(ev: ErrorEvent): void;
        onclose(ev: CloseEvent): void;
        wsmessage(data: Uint8Array, wrapper?: pbMessage): void;
        wrapper: pbMessage;
        stringData(data: Uint8Array): string;
        logData(data: Uint8Array): string | {};
        dispatchMessageEvent(data: Uint8Array, ll?: number): void;
        sendBuffer(data: Uint8Array): void;
        closeStream(code?: import("./types.js").CLOSE_CODE, reason?: string): void;
    };
} & TBase;
export {};
