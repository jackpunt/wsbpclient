import type * as jspb from 'google-protobuf';
export { className, stime } from '@thegraid/common-lib';
export { EzPromise } from '@thegraid/ezpromise';
export interface pbMessage extends jspb.Message {
}
export declare type Constructor<T> = new (...args: any[]) => T;
/** augment proto with accessor 'msgType => string' */
export declare function addEnumTypeString(msgClass: {
    prototype: object;
}, tEnum?: any, accName?: string): void;
export declare function stringData(data: any[]): string;
/**
 * websocket close codes.
 *
 * https://docs.microsoft.com/en-us/dotnet/api/system.net.websockets.websocketclosestatus
 */
export declare enum CLOSE_CODE {
    NormalClosure = 1000,
    EndpointUnavailable = 1001,
    ProtocolError = 1002,
    Empty = 1005,
    Abnormal = 1006,
    PolicyViolation = 1008
}
export declare type READY_STATE = Pick<WebSocket, "CONNECTING" | "OPEN" | "CLOSING" | "CLOSED">;
export declare type CloseInfo = {
    code: number;
    reason: string;
};
export declare function normalClose(reason: string): CloseInfo;
export declare const close_normal: CloseInfo;
export declare const close_fail: CloseInfo;
export declare function readyState(ws: WebSocket): string;
export declare type minWebSocket = {
    send: (data: any) => void;
    close: (code?: number, data?: string) => void;
    addEventListener: (method: string, listener: (event?: Event) => void) => void;
};
/** a bytearray that decodes to type T */
export declare type DataBuf<T> = Uint8Array;
export declare type AWebSocket = WebSocket;
/** standard HTML [Web]Socket events, for client (& server ws.WebSocket) */
/** what the downstream invokes/sends_to this [upstream] Driver: */
export interface WebSocketEventHandler<I extends pbMessage> {
    onopen: (ev: Event) => void | null;
    onerror: (ev: Event) => void | null;
    onclose: (ev: CloseEvent) => void | null;
    wsmessage: (buf: DataBuf<I>, wrapper?: pbMessage) => void | null;
    onmessage: (data: DataBuf<I>) => void | null;
}
export interface PbParser<T extends pbMessage> {
    deserialize(bytes: DataBuf<T>): T;
    parseEval(message: T): void;
}
/** WebSocketDriver that can be linked by an upstream driver */
export interface UpstreamDrivable<O extends pbMessage> {
    /** set upstream driver, send bytes upstream */
    connectUpStream(wsd: WebSocketEventHandler<O>): void;
    /** send close request downstream */
    closeStream(code?: CLOSE_CODE, reason?: string): void;
    /** send DataBuf downstream */
    sendBuffer(data: DataBuf<O>): void;
}
/** Generic [web] socket driver, pass message up-/down-stream to a connected WSD. */
export interface WebSocketDriver<I extends pbMessage, O extends pbMessage> extends WebSocketEventHandler<I>, UpstreamDrivable<O> {
    connectDnStream(dnstream: UpstreamDrivable<I>): this;
}
